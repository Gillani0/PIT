package sockets;
/*
 * File: ChatProgram.java
 * =======================================================
 * A simple chat program to let two computers communicate.
 */

import acm.program.*;
import acm.util.*;
import java.io.*;
import java.net.*;
import javax.swing.*;
import java.awt.event.*;

public class ChatProgram extends ConsoleProgram {
	/* The port number on which to connect/listen. */
	private static final int PORT_NUMBER = 5001;
	
	/* Our preferred size. */
	public static final int APPLICATION_WIDTH = 500;
	public static final int APPLICATION_HEIGHT = 600;
	
	/* How many columns the input field should have. */
	private static final int NUM_COLUMNS = 30;
	
	/* A BufferedReader and PrintWriter for reading and writing data,
 	 * respectively.
	 */
	private BufferedReader input;
	private PrintWriter output;
	
	/* A JTextField for typing in messages to send. */
	private JTextField text;
	
	public void init() {
		setFont("DejaVuSerif-24-BOLD");

		/* Connect to the remote computer. */
		Socket s = connect();
		println("=== Connection Established! ===");
		
		/* Get the input and output channels. */
		try {
			input = new BufferedReader(new InputStreamReader(s.getInputStream()));
			output = new PrintWriter(s.getOutputStream());
		} catch (IOException e) {
			throw new ErrorException(e);
		}
		
		/* Add the interactor we'll use to send messages. */
		text = new JTextField(NUM_COLUMNS);
		text.addActionListener(this);
		add(text, SOUTH);
	}
	
	/**
	 * Continuously receives and prints incoming messages.
	 */
	public void run() {
		try {
			while (true) {
				String line = input.readLine();
				if (line == null) break;
				
				println(">>> " + line);
			}
		} catch (IOException e) {
			throw new ErrorException(e);
		}
		println("=== Connection Closed ===");
	}
	
	/**
	 * If there's text to send, send it!
	 */
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == text) {
			sendText(text.getText());

			/* This is a nice feature that just makes it easier to type
			 * more text after we send some.
			 */
			text.setText("");
		}
	}
	
	/**
	 * Sends a string of text to the remote machine.
	 *
	 * @line The line of text to send.
	 */
	private void sendText(String line) {
		/* Actually send the message. */
		output.println(line);
		output.flush();

		/* Additionally, display the text so we can see the whole conversation. */
		println("<<< " + line);
	}
	
	/**
	 * Establishes a connection to a remote machine, returning a Socket representing
	 * that connection.
	 *
	 * @return A socket connection to a remote machine.
	 */
	private Socket connect() {
		boolean isServer = getDialog().readBoolean("Do you want to host? ", "Yes", "No");
		if (isServer) {
			return setupServer();
		} else {
			return setupClient();
		}
	}
	
	/**
	 * Waits for a remote machine to contact us, then returns a Socket that connects to
	 * it.
	 *
	 * @return A socket connection to a remote machine.
	 */
	private Socket setupServer() {
		try {
			/* Wait for someone to call us. */
			ServerSocket s = new ServerSocket(PORT_NUMBER);
			Socket client = s.accept();

			/* Say that we're done receiving incoming connections. */
			s.close();

			return client;
		} catch (IOException e) {
			throw new ErrorException(e);
		}
	}

	/**
	 * Connects to a remote machine, returning a Socket that lets us send and receive
	 * data.
	 *
 	 * @return A socket connection to a remote machine.
	 */	
	private Socket setupClient() {
		while (true) {
			try {
				String host = getDialog().readLine("Enter host: ");
				Socket s = new Socket(host, PORT_NUMBER);
				
				return s;
			} catch (IOException e) {
				getDialog().println("An error occurred trying to connect.");
			}
		}
	}
}
