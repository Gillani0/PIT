package org.test.service;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Application;

@ApplicationPath("v1/converterApp")
public class CurrencyConverterApplication extends Application{


}
